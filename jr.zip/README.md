#Joshuareddekopp.com
This is a blog and portfolio 
